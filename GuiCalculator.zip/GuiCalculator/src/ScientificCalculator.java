

public class ScientificCalculator {
    public static void main(String[] args) {
        CalculatorUI scientific = new CalculatorUI();
        scientific.setVisible(true);
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}